#include "Light.h"

GLuint Light::cont = 0;